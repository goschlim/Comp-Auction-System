// Package client is a http Client-Server of a Computer Parts Auction System.
// It contains all the code files needed to run the http server.
package client
