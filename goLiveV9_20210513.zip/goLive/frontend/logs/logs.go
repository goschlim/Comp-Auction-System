// Package logs uses customized loggings to save logs to a log file.
package logs

import (
	"crypto/sha256"
	"encoding/hex"
	"io"
	"io/ioutil"
	"log"
	"os"

	"goLive/frontend/common"
)

var ( // custom logger
	logInfo  *log.Logger // logs information
	logWarn  *log.Logger // logs warning
	logError *log.Logger // logs error
	logFatal *log.Logger // logs fatal
)

var ( // file checksum
	// folder
	logsDir = "logs/checksum/"

	// HashPath the path to file checksum
	HashPath = logsDir + "checksum.txt"

	// LogPath the path to file serverlogs
	LogPath = logsDir + "serverlogs.log"
)

func init() {
	buildLoggers(LogPath)
	buildChecksums(HashPath, LogPath)
}

// ==============================

// buildLoggers builds custom loggers.
func buildLoggers(logPath string) {
	// open log file for saving logs
	// if the file does not exist,
	// create it, or append data to write to it
	file, err := os.OpenFile(logPath,
		// O_CREATE create a new file if none exists
		// O_WRONLY open the file write-only
		// O_APPEND append data to the file when writing
		os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		// Println() followed by a call to os.Exit(1)
		Fatal("<log file not found>", err)
	}

	// update file output writer
	// based on flag set in package common
	if !common.ConstDebugSaveLogs {
		// print to terminal; not file
		file = os.Stdout

		// save all logs to output
		log.SetOutput(file)
	}

	// custom log with flags
	logInfo = log.New(file, "INFO: ", log.Ldate|log.Ltime)
	logWarn = log.New(file, "WARN: ", log.Ldate|log.Ltime)
	logError = log.New(file, "ERROR: ", log.Ldate|log.Ltime)
	logFatal = log.New(file, "FATAL: ", log.Ldate|log.Ltime)
}

// ===== [Info] =====

// Info saves information string to log file,
// based on fmt.Println.
func Info(s ...interface{}) {
	logInfo.Println(s...)
}

// Infof saves information string to log file,
// based on fmt.Printf.
func Infof(format string, s ...interface{}) {
	logInfo.Printf(format+"\n", s...)
}

// ===== [Warn] =====

// Warn saves warning string to log file,
// based on fmt.Println.
func Warn(s ...interface{}) {
	logWarn.Println(s...)
}

// Warnf saves warning string to log file,
// based on fmt.Printf.
func Warnf(format string, s ...interface{}) {
	logWarn.Printf(format+"\n", s...)
}

// ===== [Error] =====

// Error saves error string to log file,
// based on fmt.Println.
func Error(s ...interface{}) {
	logError.Println(s...)
}

// Errorf saves error string to log file,
// based on fmt.Printf.
func Errorf(format string, s ...interface{}) {
	logError.Printf(format+"\n", s...)
}

// ===== [Fatal] =====

// Fatal saves fatal string to log file,
// based on fmt.Println followed by a call to os.Exit(1).
func Fatal(s ...interface{}) {
	logFatal.Fatalln(s...)
}

// Fatalf saves fatal string to log file,
// based on fmt.Printf followed by a call to os.Exit(1).
func Fatalf(format string, s ...interface{}) {
	logFatal.Fatalf(format+"\n", s...)
}

// ==============================

// buildChecksums build checksum and log files.
func buildChecksums(hashPath string, logPath string) {
	// disable saving of checksum file
	if !common.ConstDebugSaveLogs {
		common.Debug("<file checksum save disabled>")
		return
	}

	// open file checksum
	_, err := os.Stat(hashPath)
	if err != nil {
		// if the file checksum does not exist,
		// due to first-run of the server
		if os.IsNotExist(err) {
			// create it
			SaveChecksum(hashPath, logPath)
		}
	}

	// compare logPath checksum with a stored hashPath checksum
	isSameHash, _ := compareChecksum(hashPath, logPath)
	if isSameHash {
		// checksums matched
		common.Debug("[ log data ok ]")

	} else {
		// checksums not matched
		common.Debug("[ log data compromised ]")

		// save to files
		SaveChecksum(hashPath, logPath)

		// if log.Fatal here, it will cause wrong checksum
		// to be computed due to incorrect contents saved,
		// hence, shutdown server immediately
		os.Exit(1)
	}
}

// ===== [Compute File Checksum SHA256] =====

// computeSHA256 compute file checksum based on SHA256.
func computeSHA256(logPath string) (string, error) {
	// open log file to compute checksum
	file, err := os.Open(logPath)
	if err != nil {
		Error(err)
		return "", err
	}
	// defer closing file stream
	defer file.Close()

	// use SHA256 on the log file
	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		Error(err)
		return "", err
	}

	// return hex encoded checksum if successful
	return hex.EncodeToString(hash.Sum(nil)), nil
}

// compareChecksum compares logPath hash with stored hashPath hash.
func compareChecksum(hashPath string, logPath string) (bool, error) {
	// get stored hash
	hashFile, err := ioutil.ReadFile(hashPath)
	if err != nil {
		Error(err)
		return false, err
	}

	// convert []byte file content to string
	strHash := string(hashFile)

	// compute logPath based on SHA256
	logHash, err := computeSHA256(logPath)
	if err != nil {
		Error(err)
		return false, err
	}

	return logHash == strHash, nil
}

// SaveChecksum writes checksum to file.
func SaveChecksum(hashPath string, logPath string) {
	// disable saving of checksum file
	if !common.ConstDebugSaveLogs {
		common.Debug("<file checksum save disabled>")
		return
	}

	// create file for every new write
	hashFile, err := os.Create(hashPath)
	if err != nil {
		Error(err)
		return
	}
	// defer closing file stream
	defer hashFile.Close()

	// open log file
	logFile, err := os.Open(logPath)
	if err != nil {
		Error(err)
		return
	}
	// defer closing file stream
	defer logFile.Close()

	// use SHA256 on the log file
	hash := sha256.New()
	if _, err := io.Copy(hash, logFile); err != nil {
		Error(err)
		return
	}

	// hex encoded checksum
	checksum := hex.EncodeToString(hash.Sum(nil))
	hashFile.WriteString(checksum)

	common.Debug("<file checksum saved>")
}
