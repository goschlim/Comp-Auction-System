// Package main runs the Computer Parts Auction FrontEnd Web Server.
package main

import (
	client "goLive/frontend/client"
)

func main() {
	// run server
	client.RunServer()
}
